//
//  NewsFeedViewController.swift
//  Facebook
//
//  Created by Timothy Lee on 8/3/14.
//  Copyright (c) 2014 codepath. All rights reserved.
//

import UIKit

class NewsFeedViewController: UIViewController, UIGestureRecognizerDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var feedImageView: UIImageView!
    @IBOutlet weak var wedding1View: UIImageView!
    
    @IBOutlet weak var weddingFrameView: UIView!
    
    
    var wedding1ViewFullPosition: CGPoint!
    var wedding1ViewFullScale: CGPoint!
    var wedding1ViewInitialPosition: CGPoint!
    var wedding1ViewInitialScale: CGPoint!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Assign full scale and position of wedding1View
        wedding1ViewFullPosition = CGPoint(x:0, y:-146)
        wedding1ViewFullScale = CGPoint(x:wedding1View.bounds.width, y:wedding1View.bounds.height)
        
        // Assign initial position and scale of wedding1View
        wedding1ViewInitialPosition = CGPoint(x: 0, y: 0)
        wedding1ViewInitialScale = CGPoint(x:wedding1View.bounds.width/2, y:wedding1View.bounds.height)
        
        wedding1View.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
        
        
        // Add Tap Gesture to weddingViewe1
        let tappedView1 = UITapGestureRecognizer(target: self, action: #selector(didTap1(sender:)))
        tappedView1.numberOfTapsRequired = 1;
        wedding1View.isUserInteractionEnabled = true
        wedding1View.addGestureRecognizer(tappedView1)
        
        

        // Configure the content size of the scroll view
        scrollView.contentSize = CGSize(width: 320, height: feedImageView.image!.size.height)
    }
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        scrollView.contentInset.top = 0
        scrollView.contentInset.bottom = 50
        scrollView.scrollIndicatorInsets.top = 0
        scrollView.scrollIndicatorInsets.bottom = 50
    }
    
    // Function to call when wedding1View is tapped.
    func didTap1(sender: UITapGestureRecognizer) {
        let location = sender.location(in: view)
        // User tapped at the point above. Do something with that if you want.
        print("tapped")
        print("Locatin is: \(location)")
    }
    
}
