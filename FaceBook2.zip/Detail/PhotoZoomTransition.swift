//
//  BaseZoomTransition.swift
//  Detail
//
//  Created by Alex on 11/15/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class PhotoZoomTransition: BaseTransition {
    
   // print("Perform Base Transition")
    
    var originalBaseImageViewFrame: CGRect!
//    
    override func presentTransition(containerView: UIView, fromViewController: UIViewController, toViewController: UIViewController) {
        print("yay")
////        
//        let photoViewController = toViewController as! PhotoViewController
//        let photoImageView = PhotoViewController.imageView
//        originalDetailImageViewFrame = detailImageView!.frame
//
//        let detailViewController = fromViewController as! DetailViewController
//        let selectedDetailImageView = photoViewController.selectedImageView
//
//        detailImageView!.frame = selectedImageView!.frame
//        
//        UIView.animate(withDuration: duration, animations: {
//            detailImageView!.frame = self.originalDetailImageViewFrame
//        }) { (finished: Bool) -> Void in
//            self.finish()
//        }
   }
    
//    override func dismissTransition(containerView: UIView, fromViewController: UIViewController, toViewController: UIViewController) {
//        
//        fromViewController.view.alpha = 1
//        UIView.animate(withDuration: duration, animations: {
//            fromViewController.view.alpha = 0
//        }) { (finished: Bool) -> Void in
//            self.finish()
//        }
//    }


}
