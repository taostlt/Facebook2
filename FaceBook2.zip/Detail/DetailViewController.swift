//
//  DetailViewController.swift
//  Detail
//
//  Created by Alex on 11/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//
// DETAIL VIEW:

import UIKit

class DetailViewController: UIViewController {
    var selectedDetailImageView: UIImageView!
    var photoZoomTransition: PhotoZoomTransition!

    @IBOutlet weak var imageView: UIImageView!
    var image:UIImage!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.image = image
 
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func didTapBack(_ sender: UIButton) {
          dismiss(animated: true) {
         
        }
    }
   
    @IBAction func didTap(_ sender: UITapGestureRecognizer) {
        
        print("Hello Segue")
        selectedDetailImageView = sender.view as! UIImageView
        performSegue(withIdentifier: "photoSegue", sender: nil)
        
        
//        dismiss(animated: true) {
//            
//            
//        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        print("Hello base")
        
        photoZoomTransition = PhotoZoomTransition()
        
        let photoViewController = segue.destination as! PhotoViewController
        photoViewController.modalPresentationStyle = .custom
        photoViewController.transitioningDelegate = photoZoomTransition
        photoZoomTransition.duration = 0.3
        
      //  photoViewController.image = selectedDetailImageView.image
        
    }
}
