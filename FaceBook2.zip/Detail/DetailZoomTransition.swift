//
//  DetailZoomTransition.swift
//  Detail
//
//  Created by Alex on 11/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class DetailZoomTransition: BaseTransition {
    
    var originalDetailImageViewFrame: CGRect!
    
    override func presentTransition(containerView: UIView, fromViewController: UIViewController, toViewController: UIViewController) {
        
        let detailViewController = toViewController as! DetailViewController
        let detailImageView = detailViewController.imageView
        originalDetailImageViewFrame = detailImageView!.frame
        
        let photoViewController = fromViewController as! PhotoViewController
        let selectedImageView = photoViewController.selectedImageView
        
        detailImageView!.frame = selectedImageView!.frame
        
        UIView.animate(withDuration: duration, animations: {
            detailImageView!.frame = self.originalDetailImageViewFrame  
        }) { (finished: Bool) -> Void in
            self.finish()
        }
    }
    
    override func dismissTransition(containerView: UIView, fromViewController: UIViewController, toViewController: UIViewController) {
        
        fromViewController.view.alpha = 1
        UIView.animate(withDuration: duration, animations: {
            fromViewController.view.alpha = 0
        }) { (finished: Bool) -> Void in
            self.finish()
        }
    }


}
