//
//  PhotoViewController.swift
//  Detail
//
//  Created by Alex on 11/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class PhotoViewController: UIViewController {
    
    var selectedImageView: UIImageView!
    var detailZoomTransition: DetailZoomTransition!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func didTapImage(_ sender: UITapGestureRecognizer) {
        selectedImageView = sender.view as! UIImageView
        performSegue(withIdentifier: "detailSeque", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        detailZoomTransition = DetailZoomTransition()
        
        let detailViewController = segue.destination as! DetailViewController
        detailViewController.modalPresentationStyle = .custom
        detailViewController.transitioningDelegate = detailZoomTransition
        detailZoomTransition.duration = 0.3
        
        detailViewController.image = selectedImageView.image
        
    }

}

